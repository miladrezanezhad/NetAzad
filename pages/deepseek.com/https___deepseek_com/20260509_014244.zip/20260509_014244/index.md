# Visited: https://deepseek.com
**Time:** Sat May  9 01:42:51 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (0 files)
_No media files downloaded_

## Other Links
- [/_next/static/chunks/1391-043d3b540d545b95.js](/_next/static/chunks/1391-043d3b540d545b95.js)
- [/_next/static/chunks/1820-b92b9b15d93720ec.js](/_next/static/chunks/1820-b92b9b15d93720ec.js)
- [/_next/static/chunks/2278-4469e39fec2e81cf.js](/_next/static/chunks/2278-4469e39fec2e81cf.js)
- [/_next/static/chunks/6714-9e94bbe5e922dff2.js](/_next/static/chunks/6714-9e94bbe5e922dff2.js)
- [/_next/static/chunks/8848-a97a0cf7440d4d29.js](/_next/static/chunks/8848-a97a0cf7440d4d29.js)
- [/_next/static/chunks/app/%5Blocale%5D/layout-05bbac3561f3eded.js](/_next/static/chunks/app/%5Blocale%5D/layout-05bbac3561f3eded.js)
- [/_next/static/chunks/app/%5Blocale%5D/page-b759233d47ba426e.js](/_next/static/chunks/app/%5Blocale%5D/page-b759233d47ba426e.js)
- [/_next/static/chunks/c56f180e-9dc73e98d71ae0a1.js](/_next/static/chunks/c56f180e-9dc73e98d71ae0a1.js)
- [/_next/static/chunks/main-app-0138e63140c237ca.js](/_next/static/chunks/main-app-0138e63140c237ca.js)
- [/_next/static/chunks/polyfills-c67a75d1b6f99dc8.js](/_next/static/chunks/polyfills-c67a75d1b6f99dc8.js)
- [/_next/static/chunks/webpack-69010fed35ae348d.js](/_next/static/chunks/webpack-69010fed35ae348d.js)
- [/_next/static/css/2cbd522464c80da0.css](/_next/static/css/2cbd522464c80da0.css)
- [/_next/static/css/4ed2fe305fed57cc.css](/_next/static/css/4ed2fe305fed57cc.css)
- [/_next/static/css/806c3349eef96975.css](/_next/static/css/806c3349eef96975.css)
- [/_next/static/media/e4af272ccee01ff0-s.p.woff2](/_next/static/media/e4af272ccee01ff0-s.p.woff2)
- [/en/](/en/)
- [/transparency/](/transparency/)
- [https://api-docs.deepseek.com/zh-cn/](https://api-docs.deepseek.com/zh-cn/)
- [https://api-docs.deepseek.com/zh-cn/quick_start/pricing](https://api-docs.deepseek.com/zh-cn/quick_start/pricing)
- [https://app.mokahr.com/social-recruitment/high-flyer/140576](https://app.mokahr.com/social-recruitment/high-flyer/140576)
- [https://beian.miit.gov.cn/](https://beian.miit.gov.cn/)
- [https://beian.mps.gov.cn/#/query/webSearch?code=33010502011812](https://beian.mps.gov.cn/#/query/webSearch?code=33010502011812)
- [https://cdn.deepseek.com/logo.png?x-image-process=image%2Fresize%2Cw_1920](https://cdn.deepseek.com/logo.png?x-image-process=image%2Fresize%2Cw_1920)
- [https://cdn.deepseek.com/policies/en-US/deepseek-privacy-policy.html](https://cdn.deepseek.com/policies/en-US/deepseek-privacy-policy.html)
- [https://cdn.deepseek.com/policies/en-US/deepseek-terms-of-use.html](https://cdn.deepseek.com/policies/en-US/deepseek-terms-of-use.html)
- [https://chat.deepseek.com](https://chat.deepseek.com)
- [https://download.deepseek.com/app/](https://download.deepseek.com/app/)
- [https://github.com/deepseek-ai](https://github.com/deepseek-ai)
- [https://github.com/deepseek-ai/DeepSeek-Coder](https://github.com/deepseek-ai/DeepSeek-Coder)
- [https://github.com/deepseek-ai/DeepSeek-Coder-V2](https://github.com/deepseek-ai/DeepSeek-Coder-V2)
- [https://github.com/deepseek-ai/DeepSeek-LLM](https://github.com/deepseek-ai/DeepSeek-LLM)
- [https://github.com/deepseek-ai/DeepSeek-Math](https://github.com/deepseek-ai/DeepSeek-Math)
- [https://github.com/deepseek-ai/DeepSeek-R1](https://github.com/deepseek-ai/DeepSeek-R1)
- [https://github.com/deepseek-ai/DeepSeek-V2](https://github.com/deepseek-ai/DeepSeek-V2)
- [https://github.com/deepseek-ai/DeepSeek-V3](https://github.com/deepseek-ai/DeepSeek-V3)
- [https://github.com/deepseek-ai/DeepSeek-VL](https://github.com/deepseek-ai/DeepSeek-VL)
- [https://mp.weixin.qq.com/s/8bxXqS2R8Fx5-1TLDBiEDg](https://mp.weixin.qq.com/s/8bxXqS2R8Fx5-1TLDBiEDg)
- [https://platform.deepseek.com](https://platform.deepseek.com)
- [https://status.deepseek.com](https://status.deepseek.com)
- [https://tsm.miit.gov.cn/dxxzsp/xkz/xkzgl/resource/qiyesearch.jsp?num=%E6%B5%99B2-20250178&amp;type=xuke](https://tsm.miit.gov.cn/dxxzsp/xkz/xkzgl/resource/qiyesearch.jsp?num=%E6%B5%99B2-20250178&amp;type=xuke)
- [https://twitter.com/deepseek_ai](https://twitter.com/deepseek_ai)
- [https://www.deepseek.com/](https://www.deepseek.com/)
- [https://www.deepseek.com/en/](https://www.deepseek.com/en/)
- [https://www.xiaohongshu.com/user/profile/66821202000000001b01a005](https://www.xiaohongshu.com/user/profile/66821202000000001b01a005)
- [https://www.zhihu.com/org/deepseek-75](https://www.zhihu.com/org/deepseek-75)
- [mailto:security@deepseek.com](mailto:security@deepseek.com)
- [mailto:service@deepseek.com](mailto:service@deepseek.com)

## Stats
- Links: 48
- Media: 0
